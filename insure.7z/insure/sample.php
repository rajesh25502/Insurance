<!DOCTYPE HTML>

<?php
mysql_connect("localhost","root","");
	mysql_select_db("insure");
         
if(isset($_POST['action']))
{          
    if($_POST['action']=="submit")
	{
//if(isset($_POST['submit']))
    
		
        $user  = $_POST['user'];
        $email  = $_POST['email'];
        $pswd   = $_POST['pswd'];
	mysql_query("insert into admin(user,email,pswd) Values('$user','$email','$pswd');");

		$message = "Success";
		echo $message;
     }
}
?>


<html>
<body>
<form action ="sample.php" method ="post">
			
<h3>SignUp </h3> 
					
						
<p>User Name </p>
<input type="text" name="user" required ></input>
<p>Email</p>
<input type="email" name="email" required ></input>
<p>Password</p>
<input type="password" name="pswd" required > </input> 
<input type="submit" name="submit" value="insert"></input>
						 	
					
</form>
</body>
</html>
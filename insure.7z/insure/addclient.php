<?php

  session_start();
$login_user=$_SESSION['login_user'];
    include "db.php"; 
	
	if(!isset($_SESSION['login_user']))
	 {
	    header("location: index.php");
	 }


		 
   if(isset($_POST['submit']))
	{
		$name=$_POST['name'];
		$lastname=$_POST['lastname'];
		$phone=$_POST['phone'];
		$email=$_POST['email'];
		$date=$_POST['date'];
		$age=$_POST['age'];
		$addr=$_POST['addr'];
		$country=$_POST['country'];
		$zip=$_POST['zip'];
		$adhar=$_POST['adhar'];
		$pan=$_POST['pan'];
		$policyname=$_POST['policyname'];
		$policynum=$_POST['policynum'];
		$mode=$_POST['mode'];
		$premium=$_POST['premium'];
		$tt=$_POST['tt'];
		$premdate=$_POST['premdate'];
		
		
		 if(preg_match("/^[a-zA-Z\s]+$/",$name))
			{
				if(is_numeric($age))
				{ 
					
					if(strlen($phone)==10 && ctype_digit($phone))
					{
						$query = "select phone from client where phone='".$phone."'";
						$sql=mysqli_query($dbconnection, $query);
						$sqlfetch=mysqli_fetch_array($sql);
						if (mysqli_num_rows($sql)>0)
						{
							echo "<script type='text/javascript'>alert('Phone number already exist!!!')</script>";
						}
						else
						{
							$query1="insert into client(name,lastname,phone,email,date,age,addr,country,zip,adhar,pan,policyname,policynum,mode,premium,tt,premdate) values('".$name."','".$lastname."','".$phone."','".$email."','".$date."','".$age."','".$addr."','".$country."','".$zip."','".$adhar."','".$pan."','".$policyname."','".$policynum."','".$mode."','".$premium."','".$tt."','".$premdate."');";
							$sqlquery=mysqli_query($dbconnection,$query1);
							if(!$sqlquery)
							{
			
								echo "<script type='text/javascript'>alert('There is some problem in database!!!')</script>";
							}
							else
							{
								echo "<script type='text/javascript'>alert('Record inserted!!')</script>";
				
							}
			
						}
					}
					else
					{
						echo "<script type='text/javascript'>alert('Please check whether Phone number vallid!!!')</script>";
					}
				}
				else
				{
					echo "<script type='text/javascript'>alert('Please enter vallid data for age!!!')</script>";
				}
			}
			else
			{
				echo "<script type='text/javascript'>alert('Name must be text!!!')</script>";
			}
	}
	
	$dbconnection->close();
?>

<html><head class="">


<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>insures</title>
 
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
  
  
  <meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8" />
	<title>Simple Tigra Calendar</title>

	<!-- link calendar resources -->
	<link rel="stylesheet" type="text/css" href="tcal.css" />
	<script type="text/javascript" src="tcal.js"></script> 

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="css/style(10).css" rel="stylesheet" type="text/css" media="all" class="">


<title>Insure</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="Exchange Education a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css files -->
<link href="css1/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/chromagallery.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/style.css" rel="stylesheet" type="text/css" media="all">
<!-- /css files -->
<!-- fonts -->

<!-- /fonts -->
<!-- js files -->

<!-- /js files -->



<title>Insure</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />


<script src="js/bootstrap.js"></script>

<link href="css/style1.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style5.css" rel='stylesheet' type='text/css' />

<script src="js/modernizr.custom.js"></script>

<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css/chromagallery.css" rel="stylesheet" type="text/css" media="all">




<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="University Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
 <script src="js/bootstrap.js"></script>
 <script src="js/boot.js"></script>
</head>

<body>
<form action = "" method = "post">
<div class="banner2">	 
<BR>

<h4 align="right">Hi <?php 
$login_session=$_SESSION['login_user'];
echo $login_session;?>  <a href="logout.php"> Logout </a></h4>  
	 <div class="header">
			
			 <div class="top-menu">
				 <span class="menu"></span>
				 <ul class="navig">
					 <li><a href="index1.php">Home</a></li>
					
					 <li class="active"><a href="addclient.php">ADD</a></li>
					
					 <li><a href="MainView.php">View</a></li>
					 <li><a href="MainSearch.php">Search</a></li>
				
				 </ul>
			 </div>
			 <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$("ul.navig").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->
			 <div class="clearfix"></div>
	 </div>	  
</div>


	<div class="main">
<!---728x90--->
		<h1>Employee Application Form</h1>
<!---728x90--->
		<div class="w3_agile_main_grids">
			<div class="agileits_w3layouts_main_grid">
				
					<div class="agile_main_grid_left">
						<div class="w3_agileits_main_grid_left_grid">
							<h3>Personal Details:</h3>
							<input type="text" name="name"  placeholder="Name" required="">
							<input type="email" name="email" placeholder="Email" required="">
							<input type="text" name="phone"  placeholder="Phone Number"  required="">
							<div><input type="text" name="date" class="tcal"  readonly="true" placeholder="dd/mm/yyyy" /></div>
							<textarea name="addr" placeholder="Address..." required=""></textarea>
						</div>
						<div class="w3_agileits_qualifications">
							<h3>Other Details:</h3>
							<select id="w3_agileits_select2" name="country"  class="w3layouts_select" onchange="change_country(this.value)" required="">
								<option value="1" >Select Country</option>
								<option value="America" >America</option>
								<option value="Russia" >Russia</option> 
								<option value="China" >China</option>		
								<option value="India" >India</option>
								<option value="Other">Other</option>							
							</select>
							<input type="text" name="zip" placeholder="Pin Code" required="">
							<input type="text" name="adhar" placeholder="Adhaar number" required="">
							<input type="text" name="pan" placeholder="PAN number" required="">
						</div>
					</div>
					<div class="agile_main_grid_left">
						<br>
						<br>
						<input type="text" name="lastname" placeholder="Last Name" required="">
						<input type="text" name="age" placeholder="Age" required="">
						<div class="agileits_main_grid_left_l_grids">
							<div class="w3_agileits_main_grid_left_l">
								<h2>Policy Details </h2>
							</div>
							
							<div class="clear"> </div>
						</div>
						<input type="text" name="policyname" placeholder="Policy Name" required="">
						<input type="text" name="policynum" placeholder="Policy Number" required="">
						<select id="w3_agileits_select2" name="mode"_ class="w3layouts_select" onchange="change_country(this.value)" required="">
								<option value="1" >SelectMode</option>
								<option value="2" >6_Moths</option>
								<option value="3" >1_year</option> 
						</select>
						<input type="text" name="premium" placeholder="Premium" required="">
						<input type="text" name="premdate" readonly="true" class="tcal"  placeholder="dd/mm/yyyy" />
						<input type="text" name="tt" placeholder="Table term" required="" >	
					</div>
				<input type="submit" name="submit" value="ADD"> 
			</div>
			
		</div>
	</div>
	
</form>
</body>
</html>

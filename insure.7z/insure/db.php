<!DOCTYPE HTML>
<?php
$dbconnection = new mysqli("localhost","root","","insure");
if(!$dbconnection)
{
	echo "Connection failed";
}
?>

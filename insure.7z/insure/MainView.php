<?php   session_start();
$login_user=$_SESSION['login_user'];
    include "db.php"; 
	
	if(!isset($_SESSION['login_user']))
	 {
	    header("location: index.php");
	 }
?>
<!DOCTYPE HTML>


<html>
<head>



<title>Insure</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="Exchange Education a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css files -->
<link href="css1/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/chromagallery.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/style.css" rel="stylesheet" type="text/css" media="all">
<!-- /css files -->
<!-- fonts -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="//fonts.googleapis.com/css?family=Viga" rel="stylesheet" type="text/css">
<!-- /fonts -->
<!-- js files -->
<script src="js1/modernizr.custom.js"></script>
<!-- /js files -->



<title>Insurance</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />


<script src="js/bootstrap.js"></script>

<link href="css/style1.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style5.css" rel='stylesheet' type='text/css' />

<script src="js/modernizr.custom.js"></script>

<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css/chromagallery.css" rel="stylesheet" type="text/css" media="all">

<link href="//fonts.googleapis.com/css?family=Viga" rel="stylesheet" type="text/css">
<link href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css">


<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="University Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
 <script src="js/bootstrap.js"></script>
 <script src="js/boot.js"></script>

</head>
<body>
<!-- banner --> 
<div class="banner2">
<BR>
<h4 align="right">Hi <?php 

$login_session=$_SESSION['login_user'];
echo $login_session;?>  <a href="logout.php"> Logout </a></h4>  	  
	 <div class="header">
			
			 <div class="top-menu">
				 <span class="menu"></span>
				 <ul class="navig">
					<li><a href="index1.php">Home</a></li>
					
					 <li><a href="addclient.php">ADD</a></li>
					
					 <li class="active"><a href="MainView">View</a></li>
					 <li><a href="MainSearch.php">Search</a></li>
				
				 </ul>
			 </div>
			 <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$("ul.navig").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->
			 <div class="clearfix"></div>
	 </div>	  
</div>
<!---->

<center>
<?php
							include('view.php');
							?>
<center>
</body>
</html>
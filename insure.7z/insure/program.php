
<!DOCTYPE HTML>


<html>
<head>



<title>Insure</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="Exchange Education a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css files -->
<link href="css1/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/chromagallery.css" rel="stylesheet" type="text/css" media="all">
<link href="css1/style.css" rel="stylesheet" type="text/css" media="all">
<!-- /css files -->
<!-- fonts -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="//fonts.googleapis.com/css?family=Viga" rel="stylesheet" type="text/css">
<!-- /fonts -->
<!-- js files -->
<script src="js1/modernizr.custom.js"></script>
<!-- /js files -->



<title>insure</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />


<script src="js/bootstrap.js"></script>

<link href="css/style1.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style5.css" rel='stylesheet' type='text/css' />

<script src="js/modernizr.custom.js"></script>

<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css/chromagallery.css" rel="stylesheet" type="text/css" media="all">

<link href="//fonts.googleapis.com/css?family=Viga" rel="stylesheet" type="text/css">
<link href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css">


<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="University Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
 <script src="js/bootstrap.js"></script>
 <script src="js/boot.js"></script>

</head>
<body>

<!-- banner --> 
<div class="banner2">
<BR>
	  
	 <div class="header">
			
			 <div class="top-menu">
				 <span class="menu"></span>
				 <ul class="navig">
					 <li><a href="index1.php">Home</a></li>
					
					  <li><a href="about.php">About</a></li>
					
					 <li class="active"><a href="program.php">Policies</a></li>
					 <li><a href="index.php">Agent</a></li>
				
				 </ul>
			 </div>
			 <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$("ul.navig").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->
			 <div class="clearfix"></div>
	 </div>	  
</div>
<!---->

<div class="news-section">
		<div class="container">
					<div class="news-head">
		               <h3>Insurance Policies</h3>
					   <p></p>
					</div>
					
					<div class="col-md-4 test-right01 test1">
					<img src="image/lics-delhi-new-money-back-plan-20-years-table-820-details-benefits-bonus-calculator-review-example-1-638.jpg" class="img-responsive" alt="" />
						<div class="textbox textbox1">
						<h4 class="col-md-4 date">Rs. 100000<br> <span><br></span><br><lable></lable></h4>
							
								<div class="clearfix"> </div>
						</div>
						
						<div class="culture-grids"> <a href="#about1"><h5>about</h5></a> </div>
						

			</div>

			<div class="col-md-4 test-right01 test1">
					<img src="image/unnamed.jpg" class="img-responsive" alt="" />
						<div class="textbox textbox1">
							<h4 class="col-md-4 date">Rs. 100000<br> <span><br></span><br><lable></lable></h4>
							
								<div class="clearfix"> </div>
						</div>
						
						
						<div class="culture-grids"> <a href="#about2"><h5>about</h5></a> </div>
			</div>
			<div class="col-md-4 test-right01 test1">
					<img src="image/lics-delhi-new-bima-bachat-table-816-details-benefits-bonus-calculator-review-example-1-638.jpg" class="img-responsive" alt="" />
						<div class="textbox textbox1">
						<h4 class="col-md-4 date">Rs. 100000<br> <span><br></span><br><lable></lable></h4>
							
								<div class="clearfix"> </div>
						</div>
						
						<div class="culture-grids"> <a href="#about3"><h5>about</h5></a> </div>


						
			</div>
			<div class="news">
				<div class="col-md-4 test-right01 test1">
					<img src="image/Brochure-PensionL (2).jpg" class="img-responsive" alt="" />
						<div class="textbox textbox1">
							<h4 class="col-md-4 date">Rs.100000<br> <span><br></span><br><lable></lable></h4>
							
								<div class="clearfix"> </div>
							
						</div>
							<BR>
						
						<div class="culture-grids"> <a href="#about4"><h5>about</h5></a> </div>
						
						

			</div>
				
			<div class="news">
				<div class="col-md-4 test-right01 test1">
					<img src="image/lic-new-jeevan-anand-logo-png-1414675647.png" class="img-responsive" alt="" />
						<div class="textbox textbox1">	
						<h4 class="col-md-4 date">Rs.100000<br> <span><br></span><br><lable></lable></h4>
							
							<div class="clearfix"> </div>
							
						</div>
							<BR>
						
						<div class="culture-grids"> <a href="#about5"><h5>about</h5></a> </div>*/
						
			</div>
				
			

			<div class="col-md-4 test-right01 test1">
					<img src="image/cmb.jpg" class="img-responsive" alt="" />
						<div class="textbox textbox1">
							<h4 class="col-md-4 date">Rs. 100000<br> <span><br></span><br><lable></lable></h4>
							
								<div class="clearfix"> </div>
						</div>
						<BR>
						
						<div class="culture-grids"> <a href="#about6"><h5>about</h5></a> </div>
			</div>
				

			

				
			
			<div class="clearfix"> </div>
		</div>
	</div>
</div>





<section class="about1" id="about1">
	<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>
 <p>Life Insurance is an agreement between an insurance company and a policyholder, under which the insurer guarantees 
to pay an assured some of money to the nominated beneficiary in the unfortunate event of the policyholder’s demise during the 
term of the policy. In exchange, the policyholder agrees to pay a predefined sum of money in form of premiums either on a regular
 basis or as a lump sum. If included in the contract, some other contingencies, such as a critical illness or a terminal illness 
can also trigger the payment of benefit. If defined in the contract, some other things, such as funeral expenses might also be a part of the benefits. </p>

<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
					
</section>


<section class="about2" id="about2">
	<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>
 <p>Life Insurance is an agreement between an insurance company and a policyholder, under which the insurer guarantees 
to pay an assured some of money to the nominated beneficiary in the unfortunate event of the policyholder’s demise during the 
term of the policy. In exchange, the policyholder agrees to pay a predefined sum of money in form of premiums either on a regular
 basis or as a lump sum. If included in the contract, some other contingencies, such as a critical illness or a terminal illness 
can also trigger the payment of benefit. If defined in the contract, some other things, such as funeral expenses might also be a part of the benefits. </p>

<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
					
</section>


<section class="about3" id="about3">
	<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>
 <p>Life Insurance is an agreement between an insurance company and a policyholder, under which the insurer guarantees 
to pay an assured some of money to the nominated beneficiary in the unfortunate event of the policyholder’s demise during the 
term of the policy. In exchange, the policyholder agrees to pay a predefined sum of money in form of premiums either on a regular
 basis or as a lump sum. If included in the contract, some other contingencies, such as a critical illness or a terminal illness 
can also trigger the payment of benefit. If defined in the contract, some other things, such as funeral expenses might also be a part of the benefits. </p>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
</section>


<section class="about4" id="about4">
	<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>
 <p>Life Insurance is an agreement between an insurance company and a policyholder, under which the insurer guarantees 
to pay an assured some of money to the nominated beneficiary in the unfortunate event of the policyholder’s demise during the 
term of the policy. In exchange, the policyholder agrees to pay a predefined sum of money in form of premiums either on a regular
 basis or as a lump sum. If included in the contract, some other contingencies, such as a critical illness or a terminal illness 
can also trigger the payment of benefit. If defined in the contract, some other things, such as funeral expenses might also be a part of the benefits. </p>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
</section>


<section class="about5" id="about5">
	<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>
 <p>Life Insurance is an agreement between an insurance company and a policyholder, under which the insurer guarantees 
to pay an assured some of money to the nominated beneficiary in the unfortunate event of the policyholder’s demise during the 
term of the policy. In exchange, the policyholder agrees to pay a predefined sum of money in form of premiums either on a regular
 basis or as a lump sum. If included in the contract, some other contingencies, such as a critical illness or a terminal illness 
can also trigger the payment of benefit. If defined in the contract, some other things, such as funeral expenses might also be a part of the benefits. </p>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
<BR>
</section>


<section class="about6" id="about6">
	<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>
 <p>Life Insurance is an agreement between an insurance company and a policyholder, under which the insurer guarantees 
to pay an assured some of money to the nominated beneficiary in the unfortunate event of the policyholder’s demise during the 
term of the policy. In exchange, the policyholder agrees to pay a predefined sum of money in form of premiums either on a regular
 basis or as a lump sum. If included in the contract, some other contingencies, such as a critical illness or a terminal illness 
can also trigger the payment of benefit. If defined in the contract, some other things, such as funeral expenses might also be a part of the benefits. </p>

</section>










</body>
</html>
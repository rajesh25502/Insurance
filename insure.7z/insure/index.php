<?php
include 'db.php';
	
	if(isset($_POST['login']))
    {
		session_start();
		
       $user=$_POST['user'];
		$pswd=$_POST['pswd'];
		
		$_SESSION['login_user']=$user;
		
        $query = "select email from admin where user='".$user."' and pswd='".$pswd."'";
      $sql=mysqli_query($dbconnection, $query);
	  $sqlfetch=mysqli_fetch_array($sql);
		if (mysqli_num_rows($sql) == 1)
        {
			$_SESSION['login_user']=$user;
			header("location: addclient.php");
           echo "<script type='text/javascript'>alert('SignIn Sucessfull!!!')</script>";
			
        }
        else
        {	
			echo "<script type='text/javascript'>alert('Invalid email or password!!!')</script>";
           
        }        
    }
	
 ?>

<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>insure login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="css/style11.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
</head>
<body>

<!-- banner --> 
<div class="banner2">
<BR>
	  
	 <div class="header">
			
			 <div class="top-menu">
				 <span class="menu"></span>
				 <ul class="navig">
					 <li><a href="index1.php">Home</a></li>
					
					 <li><a href="about.php">About</a></li>
					
					 <li><a href="program.php">Policies</a></li>
					
					 <li class="active"><a href="index.php">Agent</a></li>
				
				 </ul>
			 </div>
			 <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$("ul.navig").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->
			 <div class="clearfix"></div>
	 </div>	  
</div>
<!---->



<!-- main -->
<center>
<div data-vide-bg="video/Ipad" style="position: relative;">
<div class="center-container" align="center">
<div class="w3ls-header">
		<h1></h1>
			<!---728x90--->
	<div class="header-main">
	
		<div class="videologin" align="center">
		
		
			<h2>Registration</h2>
			<!---728x90--->
			<div class="header-bottom">
				<div class="header-right w3agile">
					<div class="header-left-bottom agileinfo">
						<form action="" method="post">
							<div class="icon1">
								<i class="fa fa-user-o" aria-hidden="true"></i>
								<input type="text" name="user" placeholder="Your name" required="">
							</div>
							<div class="icon1">
								<i class="fa fa-unlock-alt" aria-hidden="true"></i>
								<input type="password" name="pswd" placeholder="password" required="">
							</div>
							<label class="anim">
								<input type="checkbox" class="checkbox">
								<span> Stay logged in </span> 
							</label>
							<a href="https://p.w3layouts.com/demos_new/template_demo/14-06-2017/career_multi_forms-demo_Free/1336356120/web/index.html#" class="forgot">forgot password?</a>
							<div class="bottom">
								<input type="submit" name="login" value="Login">
							</div>
							
							
						</form>	
					</div>
				</div>
			</div>
		</div>
		
		
		<div class="clear"></div>
	</div>
	<br><br><br><br><br><br><br>
	<!-- copyright start here -->
	<div class="copyright">
		<p>©ShreyaSuresh</p>
	</div>
	<!--copyright end here-->
</div>
</div>
</div>
</center>
</body></html>



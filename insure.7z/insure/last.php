<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
include('db.php');
if(isset($_POST['submit']))
  {
   $user=$_POST['user'];
   $email=$_POST['email'];
   $pswd=$_POST['pswd'];
$query = "select email from admin where user='".$user."' and pswd='".$pswd."'";
      $sql=mysqli_query($dbconnection, $query);
	  $sqlfetch=mysqli_fetch_array($sql);
		if (mysqli_num_rows($sql)==1)
		{
            echo "Email already exist!!";
        }
        else
        {
            $query1="insert into admin(user,email,pswd) values('".$user."','".$email."','".$pswd."')";
            $sqlquery=mysqli_query($dbconnection,$query1);
			if(!$sqlquery)
			{
				echo "There is some problem!!".mysqli_error($dbconnection);
			}
			else
			{
				echo "Signup Sucessfull!!";
				header("location: index.html");
			}
			
        }


 }
?>


<html xmlns="http://www.w3.org/1999/xhtml" >
<head id="Head1" runat="server">
<title>Index_Product_Info" Title=":: Online Gift Shopping India ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
</head>
<body>
    <form method="post" action="">
	
	<h3>SignUp </h3> 
					
						
<p>User Name </p>
<input type="text" name="user" required ></input>
<p>Email</p>
<input type="email" name="email" required ></input>
<p>Password</p>
<input type="password" name="pswd" required > </input> 
	 <input type="submit" name="submit" value="Login">
	 
	 
	  </form>
</body>
</html>
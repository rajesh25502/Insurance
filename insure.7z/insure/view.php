<?php
include 'db.php';
$query = "select name,lastname,phone,email,addr,date,pan,adhar from client";
      $sql=mysqli_query($dbconnection, $query);
	  //$sqlfetch=mysqli_fetch_assoc($sql);
	  echo "<BR><BR><BR><BR>";
	  echo "<h3>Personal Detail</h3><BR>";
	  echo "<table border='1' width='1200px'><tr><th>NAME</th><th>LAST NAME</th><th>PHONE NUMBER</th><th>EMAIL ADDRESS</th><th>ADDRESS</th>";
	  echo "<th>DATE OF BIRTH</th><th>PAN CARD NUMBER</th><th>ADHAR NUMBER</th></tr>";
	  if (mysqli_num_rows($sql)>0)
		{	
			
			while($row=mysqli_fetch_assoc($sql))
			{
				
			echo "<tr><td>$row[name]</td><td>$row[lastname]</td><td>$row[phone]</td><td>$row[email]</td><td>$row[addr]</td><td>$row[date]</td><td>$row[pan]</td><td>$row[adhar]</td></tr>";
			//echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td><td>$row[6]</td><td>$row[7]</td></tr>";
			}
        }
		else
		{
			echo "<script type='text/javascript'>alert('Data not found!!!')</script>";
		}
		echo "</table>";
		
		
		$query1 = "select name,policyname,policynum,premdate,premium,mode,tt,pan,adhar from client";
      $sql1=mysqli_query($dbconnection, $query1);
	  //$sqlfetch=mysqli_fetch_array($sql1);
	  echo "<BR><BR>";
	  echo "<h3>Policy Detail</h3><BR>";
	  echo "<table border='1' width='1200px'><tr><th>NAME</th><th>POLICY NAME</th><th>POLICY NUMBER</th><th>PREMIUM DATE</th><th>PREMIUM</th><th>MODE</th>";
	  echo "<th>TABLE AND TERM</th><th>PAN CARD NUMBER</th><th>ADHAR NUMBER</th></tr>";
	  if (mysqli_num_rows($sql1)>0)
		{
			while($row1=mysqli_fetch_array($sql1))
			{
				echo "<tr><td>$row1[0]</td><td>$row1[1]</td><td>$row1[2]</td><td>$row1[3]</td><td>$row1[4]</td><td>$row1[5]</td><td>$row1[6]</td><td>$row1[7]</td><td>$row1[8]</td></tr>";
			
			}
        }
		else
		{
			echo "<script type='text/javascript'>alert('Data not found!!!')</script>";
		}
		echo "</table>";
?>
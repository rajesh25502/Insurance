<?php   session_start();
    include "db.php"; 
	
	 if(!isset($_SESSION['username']))
	 {
	    header("location: index.php");
	 }
?>




<?php
include 'db.php';
$query = "select name from client";
      $sql=mysqli_query($dbconnection, $query);
	  //$sqlfetch=mysqli_fetch_assoc($sql);
	  echo "<BR><BR><BR><BR>";
	 
	  if (mysqli_num_rows($sql)>0)
		{	
	

			echo "<b> Search by name:<select name=name></b>";
			while($row=mysqli_fetch_array($sql))
			{
			echo "<option>$row[0]</option>";
			//echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td><td>$row[6]</td><td>$row[7]</td></tr>";
			}
			echo "</select>";
        }
		else
		{
			echo "<script type='text/javascript'>alert('Data not found!!!')</script>";
		}
		
?>




<!DOCTYPE HTML>
<html>
<head>
<title>Insurance agent</title>




<!-- <title>Collegiate a Education category Flat Bootstrap Responsive Website Template | :: W3layouts</title> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="Exchange Education a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css files -->
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css/chromagallery.css" rel="stylesheet" type="text/css" media="all">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all">
<!-- /css files -->
<!-- fonts -->
<link href="//fonts.googleapis.com/css?family=Open+Sans:100,100,100,100,100" rel="stylesheet" type="text/css">
<link href="//fonts.googleapis.com/css?family=Viga" rel="stylesheet" type="text/css">
<!-- /fonts -->
<!-- js files -->
<script src="js/modernizr.custom.js"></script>
<!-- /js files -->



<title>Insure</title>
<link href="css/bootstrap1.css" rel='stylesheet' type='text/css' />


<script src="js/bootstrap.js"></script>

<link href="css/style1.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style5.css" rel='stylesheet' type='text/css' />

<script src="js/modernizr.custom.js"></script>

<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css/chromagallery.css" rel="stylesheet" type="text/css" media="all">

<link href="//fonts.googleapis.com/css?family=Viga" rel="stylesheet" type="text/css">
<link href="//fonts.googleapis.com/css?family=Open+Sans:100,100,100,100,100" rel="stylesheet" type="text/css">


<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="University Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
 <script src="js/bootstrap.js"></script>
 <script src="js/boot.js"></script>

</head>

<body>
<!-- banner --> 
<div id="Home" class="banner2">
<BR>
  	  
	 <div class="header">
			
			 <div class="top-menu">
				 <span class="menu"></span>
				 <ul class="navig">
					 <li><a href="index1.php">Home</a></li>
					
					 <li class="active"><a href="about.php">About</a></li>
					
					 <li><a href="program.php">Policies</a></li>
					
					 <li><a href="index.php">Agent</a></li>
				
				 </ul>
			 </div>
			 <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$("ul.navig").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->
			 <div class="clearfix"></div>
	 </div>	  
</div>
<!---->


<div class="about-sec">
	 <div class="container">
		  <div class="about-head"><br>
			<h2>About</h2><br>
			<h3>Life Insurance</h3>
			<p>Life Insurance plan is the safest and the most secure way to protect your family or dependents against financial
contingencies that may arise post the unfortunate event of your untimely demise. Under a Life Insurance Contract in
 India, the insurer assures to pay a definite sum to the policyholder�s family on his demise during the policy term.</p>

<h3>       What is Life Insurance? </h3> 
	
<p>Life Insurance is an agreement between an insurance company and a policyholder, under which the insurer guarantees 
to pay an assured some of money to the nominated beneficiary in the unfortunate event of the policyholder�s demise during the 
term of the policy. In exchange, the policyholder agrees to pay a predefined sum of money in form of premiums either on a regular
 basis or as a lump sum. If included in the contract, some other contingencies, such as a critical illness or a terminal illness 
can also trigger the payment of benefit. If defined in the contract, some other things, such as funeral expenses might also be a part of the benefits. </p>

			<h3>       Life Insurance Policy Types </h3> 

				<ul class="rslides" id="slider" >
						

						    <li><h5>1.   Term Insurance </h5></li>

							<li><h5>2.   Endowment Policy</h5></li>

							<li><h5>3.   ULIP - Unit Linked Insurance Plan</h5></li>
							<li><h5>4.   Money Back Life Insurance </h5></li>
							<li><h5>5.   Whole Life Insurance</h5></li>
				</ul>
<br>
<h3>      Life Insurance - Q&A <br>
Q. Why Should You Buy a Life Insurance Policy?
</h3> 
<p><b>Besides offering financial protection to your family, life insurance policies offer the following benefits:-</b></p>
<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>

<p><b>Tax benefits: </b> The maturity benefits offered by life insurance policies are eligible for tax benefits under Section 10(10D) 
of the Income Tax Act in India. Also, premiums paid on life insurance policy get tax deductions under Section 80C of the Act.  
Planning your life insurance cover the best way possible may even mean that that your t
ax slabs will be different and you may be able to plan your income to fall under a lower slab than a higher one.</p>

<p><b>Encourages contribution: </b> Most often, life insurance policy is taken for a specified goal, such as child�s education and marriage.
 In this way, it discourages the person from utilizing those funds for any other motive.  Slowly and steadily, your life insurance policy helps
 you to increase your corpus and allows you to realize your best 
dreams without too much effort. The only effort required from you is to pay the life insurance premium on time. </p>

<p><b>Plan for retirement: </b>Planning for retirement is the biggest advantage of life insurance plans. Most of the country�s working population
 are not covered under retirement plans. The EPF, PPF and other pension plans only cover a small portion of the population. The only way out 
seem to be life insurance as the life insurance policy helps build up a corpus for retirement and also provides life insurance cover against a
 myriad of life�s problems at the same time. The best life 
insurance companies offer a range of payout options. These include lump sum payment, annuities, and monthly payments.</p>

<p><b>Certainty:</b> Once a goal has been set, life insurance policy is the best means to fund that goal. 
This is because it gives a peace of mind that in case of any unfortunate event such as death and critical illness; 
the sum assured paid by the life insurer will be sufficient to meet future goals of the policyholder or family. 
People can worry less about what will happen to their families and loved ones in case something unfortunate or unexpected
 happens to them with an adequate life insurance cover.</p>

<p><b>Provide life insurance cover for life�s unfortunate problems:</b> : A life insurance policy safeguards against various small or big problems that
 life may throw at you. Whether it�s providing life insurance cover against hospitalisation, day care, post surgical treatment, or simply helping 
you build up your wealth in a safe secure manner, a life insurance policy does all this and more. Moreover, the Indian life insurance companies 
offer a range of policies that help the individuals to buy policies for themselves or their families for a variety of end purposes. In addition, a life 
insurance cover guards against any unfortunate or unforeseen events such as critical illnesses and even death.</p>

<br>
<h3>    Q. When should you buy life insurance?</h3> 
<p>The minute you have people dependent on you, you should buy an insurance cover. The younger the age, lower will 
be the premium. Anyone who is married and has a family to support should think of purchasing the best life insurance policy.
 Even single persons can choose the best life insurance plans to get tax benefits.
 Further, after marriage, they can add their spouse and children as beneficiary in the insurance contract. </p>
<p>There is no age limit to start buying life insurance cover. You should buy the best life insurance policy as soon as the requirement arises.
 In fact, life insurance cover should start from childhood to insure against illnesses and sudden hospitalisations from fever or stomach aches, and should also 
be present for the elderly to cover against age-related illnesses, regular check-ups, hospitalisation, etc. </p>

<br>
<h3>    Q. How much life insurance do you require? </h3> 
<p>Your life insurance needs depend on a various factors such as your marital status, age and gender. For instance, 
when you are young, you may not need a life insurance but as you grow old and your 
financial responsibilities get increased, you may need the best life insurance policy of high sum assured.</p>

<br>
<h3>     Q.  What are the immediate financial expenses that your family may require upon your immediate death? </h3> 
<p>Though this is not a question people like to think about, it is a question that lies at the foundation of life.
 Death like birth is inevitable and causes havoc wherever it touches people�s lives. The after effects are numbing 
for the rest of the family members and people take months, if not years, to come out of their grief. </p>
<p>Life insurance companies in India provide some of the best insurance covers for the Indian citizens. These covers
 not only take a long term view and look after future expenses, they also help the family to meet the immediate expenses like 
repatriation costs, funeral expenses, etc. This may seem like a minor thing to think about against the backdrop of such a major life changing event, but the 
performance of the rites and rituals cost money and some funds to take care of these expenses always help. </p>
<p>Buying a life insurance policy that takes care of these immediate expenses ensure that
 the insured has taken care of his or her family in the best manner possible. </p>

<br>
<h3>      Q. How to find present expenses to get the best life insurance plans?</h3> 
<p>Finding the present cost of living requires breaking up of all the current expenses into their respective categories or expense heads. 
You can do it the old fashioned way using a notepad and a pen or pencil or
 the new way of using a financial website or an app. Let�s plan the normal expenses under these categories: </p>
<p><b>Rent:</b> </p>
<p><b>Groceries and food expenses:</b> </p>
<p><b>Clothes:</b> </p>
<p><b>School, college and tuition fees:</b> </p>
<p><b>Taxes and Other Fees:</b> </p>
<p><b>Entertainment expenses:</b> </p>
<p><b>Holidays:</b> </p>
<p><b>Fees for Helpers:</b> </p>
<p><b>Utility bills:</b> </p>
<p><b>Travel expenses:</b> </p>

<br>
<h3>     Q. How to find future expenses to get the best life insurance plans?</h3> 
<p>For most of the expenses listed under the current expenses, you can arrive at the yearly and thus the future
 expense by calculating the annual cost from the monthly costs. One of the best ways to get adequate cover for these expenses is
 to get a lump sum that you or your family can invest in secure and safe investments like bank fixed deposits or secure debt funds.
 The payment from these investments,
 whether as interest or otherwise, will help you get the necessary amount to pay off the monthly bills. </p>
<p>Another thing you can do is to check which of the life insurance plans offer monthly payouts. Since these life 
insurance companies understand the nature of expenses, the best of them have come out with a host of plans for life insurance
 policyholders in India. These plans work just like a regular salary as the life insurance company deposits the amount on a specific date 
every month. These regular payouts make it easier to manage your expenses.
 Some other expenses you have to keep in mind for the future are: </p>
<p><b>Children�s expenses:</b>Some expenses like children�s higher studies and wedding can be easily covered with life insurance plans. You 
can allocate a certain amount depending upon your rough estimate to arrive at the number. You can also buy different plans to cover for these expenses. 
Since higher studies or a wedding happen only when the children have crossed the age of 18 and 21 respectively, opting for child life insurance plans when
 your children are 1-5 years old means that a significant corpus builds up by the
 time they reach these specific ages in addition to providing them with a protective life insurance cover.  </p>
<p><b>Healthcare expenses: </b>Your healthcare expenses or those of your spouse or your parents will increase as you age.
 Life insurance plans should be able to cover for these exigencies. One way to take care of these is to buy mediclaim policies but life
 insurance plans also work out well. In addition, some of the best life insurance companies in India offer comprehensive plans that also take into account these
 expenses or provide optional riders that allow you to add these covers for some additional premium amount. </p>
<p><b>Retirement expenses: </b>Planning for your retirement and paying the premium for such a life insurance policy 
would form the bulk of your salary outgo while planning for the future. Retirement planning using life insurance plans are a
 great way to save for your retirement and build up a retirement corpus. You must ensure that you buy life insurance plans
 that ensure you are able to maintain your current standard of living and also go easy on your wallet. The best way to do this 
is to compare the life insurance plans available from the various life 
insurance companies in India. Thereafter, you can choose the life insurance cover or covers that work for you.  </p>




		  </div>
		  
		  
	</div>
</div>




<!----footer--->
			<div class="footer">
<font color="yellow">
				<div class="container">
					<div class="copy">
		              <p>@ShreyaSuresh</p>
		            </div>
					
				</div>
 </font> 
			</div>
	<!--start-smoth-scrolling-->
			<script type="text/javascript">
								jQuery(document).ready(function($) {
									$(".scroll").click(function(event){		
										event.preventDefault();
										$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
									});
								});
								</script>
							<!--start-smoth-scrolling-->
						<script type="text/javascript">
									$(document).ready(function() {
										/*
										var defaults = {
								  			containerID: 'toTop', // fading element id
											containerHoverID: 'toTopHover', // fading element hover id
											scrollSpeed: 1200,
											easingType: 'linear' 
								 		};
										*/
										
										$().UItoTop({ easingType: 'easeOutQuart' });
										
									});
								</script>
		<a href="#Home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>



</body>
</html>
<html>
<body>
<center>
<form action="" method="post">
<br>
<br><br>
<b> Search by name:<input type="text" name="name" placeholder="Name" required=""></b>
<input type="submit" name="submit" value="search">
</form>
</body>
</html>


<?php
include 'db.php';
if(isset($_POST['submit']))
{
		$name=$_POST['name'];
		$query = "select name,policynum,email,premium,phone,policyname from client where name='".$name."'";
      $sql=mysqli_query($dbconnection, $query);
	  //$sqlfetch=mysqli_fetch_assoc($sql);
	  echo "<BR><BR><BR><BR>";
	  echo "<h3>POLICY HOLDERS DETAIL</h3><BR>";
	  echo "<table border='1' width='1200px'><tr><th>NAME</th><th>PPLICY NUMBER</th><th>EMAIL ADDRESS</th><th>PREMIUM AMOUNT</th>";
	  echo "<th>PHONE NUMBER</th><th>POLICY NAME</th></tr>";
		if (mysqli_num_rows($sql)>0)
		{	
			
			while($row=mysqli_fetch_array($sql))
			{
				
			//echo "<tr><td>$row[name]</td><td>$row[lastname]</td><td>$row[phone]</td><td>$row[email]</td><td>$row[addr]</td><td>$row[date]</td><td>$row[pan]</td><td>$row[adhar]</td></tr>";
			echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td></tr>";
			}
        }
		else
		{
			echo "<script type='text/javascript'>alert('Data not found!!!')</script>";
		}
	echo "</table>";
}
	
		
?>


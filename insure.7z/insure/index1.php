﻿
<!DOCTYPE HTML>
<html>
<head>
<title>Insurance agent</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

<script src="js/bootstrap.js"></script>

<link href="css/style.css" rel='stylesheet' type='text/css' />

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="University Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>

</head>
<body>
<!-- banner -->
<script src="js/responsiveslides.min.js"></script>
<script>  
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>  


<div id="Home" class="banner">	
<BR>

<div class="top-menu">
				 <span class="menu"></span>
				 <ul class="navig">
					  <li class="active"><a href="index1.php">Home</a></li>
					
					 <li><a href="about.php">About</a></li>
					
					 <li><a href="program.php">Policies</a></li>
					
					 <li><a href="index.php">Agent</a></li>
				 </ul>
			 </div>	 
			
<br>
<br>
<br><br><br><br><br><br><br><br><br><br>
			  <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$("ul.navig").slideToggle("slow" , function(){
					});
				});
		 </script>
		 
 	<div class="slider" color="##763c61" font-size="200%" >
		 <div class="caption">

			 <div class="container">
				  <div class="callbacks_container">
					<font color="green">
					  <ul class="rslides" id="slider" >
						<marquee direction="left" behavior="slide" >

						    <li><h3>-> Term Insurance </h3></li>
</marquee>
<marquee direction="left" behavior="slide"> <br>
							<li><h3>-> Endowment Policy</h3></li>
</marquee>	
<marquee direction="left" behavior="slide"><br>
							<li><h3>-> Unit Linked Insurance Plans (ULIPs)</h3></li>
</marquee>
<marquee direction="left" behavior="slide"><br>
							<li><h3>-> Money Back Life Insurance</h3></li>
</marquee>
<marquee direction="left" behavior="slide"><br>
							<li><h3>-> Whole Life Insurance</h3></li>
</marquee>
<marquee direction="left" behavior="slide"><br>
							<li><h3>-> Child Insurance</h3></li>
</marquee>
<marquee direction="left" behavior="slide"><br>
							<li><h3>-> Pension Plans</h3></li>
</marquee>	
					  </ul>	
					
						<div class="clearfix"></div>
						</font>
				  </div>
			  </div>
		  </div>
	  </div>



 </div>





<!----footer--->
			<div class="footer">
<font color="yellow">
				<div class="container">
					<div class="copy">
		              <p>@ShreyaSuresh</p>
		            </div>
					
				</div>
 </font> 
			</div>
	<!--start-smoth-scrolling-->
			<script type="text/javascript">
								jQuery(document).ready(function($) {
									$(".scroll").click(function(event){		
										event.preventDefault();
										$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
									});
								});
								</script>
							<!--start-smoth-scrolling-->
						<script type="text/javascript">
									$(document).ready(function() {
										/*
										var defaults = {
								  			containerID: 'toTop', // fading element id
											containerHoverID: 'toTopHover', // fading element hover id
											scrollSpeed: 1200,
											easingType: 'linear' 
								 		};
										*/
										
										$().UItoTop({ easingType: 'easeOutQuart' });
										
									});
								</script>
		<a href="#Home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>



</body>
</html>